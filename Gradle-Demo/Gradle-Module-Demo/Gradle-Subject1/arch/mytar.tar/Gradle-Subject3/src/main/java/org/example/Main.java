package org.example;

/**
 * @projectName: ${PROJECT_NAME}
 * @package: org.example
 * @className: ${NAME}
 * @author: WQL-KXJ
 * @description: TODO
 * @date: ${DATE} ${TIME}
 * @version: v2.0
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}